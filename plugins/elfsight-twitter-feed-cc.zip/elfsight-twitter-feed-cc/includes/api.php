<?php

if (!defined('ABSPATH')) exit;

if (PHP_VERSION_ID > 50600) {
    require_once realpath(__DIR__ . '/..') . '/api/vendor/autoload.php';
}

if (!class_exists('ElfsightTwitterFeedApi')) {
    class ElfsightTwitterFeedApi extends ElfsightTwitterFeedApiCore {
        private $routes = array(
            'request' => 'requestController',
            'auth' => 'authController',
            'link-preview' => 'linkPreviewController'
        );

        private $apiAuth;
        private $apiConfig = array(
            'consumer_key' => 'mUspbYs9qCjq77OtR5uvEISxy',
            'consumer_secret' => 'cC9hNrjmdRm2Zc6kP39ACTNFFF7nqH7ZIDDgo9PkdpFlz0iAMq',
            'base_url' => 'https://api.twitter.com/1.1/',
            'auth_url' => 'https://storage.elfsight.com/auth/twitter/'
        );

        public function __construct($config) {
            parent::__construct($config, $this->routes);
        }

        public function authController() {
            $user_id = $this->input('user_id');
            $twitter_user_id = $this->input('twitter_user_id', false, false);

            if (empty($twitter_user_id)) {
                $auth_url = $this->apiConfig['auth_url'];
                $redirect_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

                $auth_url = $this->Helper->addQueryParam($auth_url, 'user_id', $user_id);
                $auth_url = $this->Helper->addQueryParam($auth_url, 'redirect_url', urlencode($redirect_url));

                header("Location: $auth_url");
                exit();
            } else {
                $twitter_data = array(
                    'twitter_user_id' => $twitter_user_id,
                    'twitter_user_nickname' => $this->input('twitter_user_nickname', false, true),
                    'oauth_token' => $this->input('twitter_oauth_token', false, true),
                    'oauth_token_secret' => $this->input('twitter_oauth_token_secret', false, true),
                );

                $json_data = json_encode($twitter_data);

                if ($this->User->set($user_id, $json_data)) {
                    echo "<script>window.opener.postMessage({'action': 'token', 'status': 1, 'data': $json_data}, '*'); window.close();</script>";
                } else {
                    die();
                }
            }
        }

        public function requestController(){
            $url = $this->input('q');
            $url_parts = parse_url($url);

            $cache_key = $this->Cache->keyFromQuery($url);
            $data = $this->Cache->get($cache_key);

            if (empty($data)) {
                $user_id = $this->input('user_id');
                $user = $this->User->get($user_id);
                $user_data = json_decode($user['data'], true);

                if (empty($user)) {
                    $this->error(400, 'invalid request', 'user not found');
                }

                $this->apiAuth = array(
                    'oauth_access_token_secret' => $user_data['oauth_token_secret'],
                    'oauth_access_token'        => $user_data['oauth_token']
                );

                $full_url = $this->apiConfig['base_url'] . $url;

                $oauth = $this->twitterBuildOauth($url_parts);

                $response = $this->request('get', $full_url, array(
                    'headers' => $this->twitterBuildAuthorizationHeaders($oauth)
                ));

                if (!empty($response)) {
                    if (!empty($response['body']) && !empty($response['http_code']) && $response['http_code'] === '200') {
                        $data = $response['body'];

                        $this->Cache->set($cache_key, $data);
                    } else {
                        return $this->error();
                    }
                } else {
                    return $this->error();
                }
            }

            return $this->response($data, true);
        }

        public function linkPreviewController() {
            if (!class_exists('LinkPreview\LinkPreview')) {
                return $this->response(array());
            }

            $url = urldecode($this->input('q'));

            $cache_key = $this->Cache->keyFromQuery($url);
            $data = $this->Cache->get($cache_key);

            if (empty($data)) {
                $linkPreview = new LinkPreview\LinkPreview($url);

                try {
                    $parsed = $linkPreview->getParsed();

                    foreach ($parsed as $parserName => $link) {
                        $data = array(
                            'url' => $url,
                            'title' => $link->getTitle(),
                            'description' => $link->getDescription(),
                            'cover' => $link->getImage()
                        );
                    }
                } catch (Exception $e) {}

                if (!empty($data)) {
                    $data = json_encode($data);
                    $this->Cache->set($cache_key, $data);
                } else {
                    $data = json_encode(array());
                }
            }

            return $this->response($data, true);
        }

        private function twitterBuildOauth($url_parts) {
            $base_url = $this->apiConfig['base_url'] . $url_parts['path'];
            if (!empty($url_parts['query'])) {
                parse_str($url_parts['query'], $url_arguments);

            } else {
                $url_arguments = array();
            }

            $oauth = array(
                'oauth_consumer_key' => $this->apiConfig['consumer_key'],
                'oauth_nonce' => time(),
                'oauth_signature_method' => 'HMAC-SHA1',
                'oauth_token' => $this->apiAuth['oauth_access_token'],
                'oauth_timestamp' => time(),
                'oauth_version' => '1.0'
            );

            $base_info = $this->twitterBuildBaseString($base_url, 'GET', array_merge($oauth, $url_arguments));
            $composite_key = rawurlencode($this->apiConfig['consumer_secret']) . '&' . rawurlencode($this->apiAuth['oauth_access_token_secret']);
            $oauth_signature = base64_encode(hash_hmac('sha1', $base_info, $composite_key, true));
            $oauth['oauth_signature'] = $oauth_signature;

            return $oauth;
        }

        private function twitterBuildBaseString($base_url, $method, $params) {
            $r = array();

            ksort($params);

            foreach ($params as $key => $value) {
                $r[] = "$key=" . rawurlencode($value);
            }

            return $method . "&" . rawurlencode($base_url) . '&' . rawurlencode(implode('&', $r));
        }

        private function twitterBuildAuthorizationHeaders($oauth) {
            $values = array();

            foreach ($oauth as $key => $value) {
                $values[] = "$key=\"" . rawurlencode($value) . "\"";
            }

            return array(
                'Authorization' => 'OAuth ' . implode(', ', $values),
                'Expect' => ''
            );
        }
    }
}