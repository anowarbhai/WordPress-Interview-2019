/*
    Elfsight Twitter Feed
    Version: 1.2.0
    Release date: Tue May 14 2019

    https://elfsight.com

    Copyright (c) 2019 Elfsight, LLC. ALL RIGHTS RESERVED
*/

/*!
 * 
 * 	elfsight.com
 * 
 * 	Copyright (c) 2019 Elfsight, LLC. ALL RIGHTS RESERVED
 * 
 */
!function(t){var i={};function e(r){if(i[r])return i[r].exports;var s=i[r]={i:r,l:!1,exports:{}};return t[r].call(s.exports,s,s.exports,e),s.l=!0,s.exports}e.m=t,e.c=i,e.d=function(t,i,r){e.o(t,i)||Object.defineProperty(t,i,{configurable:!1,enumerable:!0,get:r})},e.n=function(t){var i=t&&t.__esModule?function(){return t.default}:function(){return t};return e.d(i,"a",i),i},e.o=function(t,i){return Object.prototype.hasOwnProperty.call(t,i)},e.p="",e(e.s=0)}([function(t,i){(window.eapps=window.eapps||{}).observer=function(t){t.$watch("widget.data.contentToDisplay",function(){i(t)}),t.$watch("widget.data.userId",function(){e(t)});var i=function(t){"account"===t.widget.data.contentToDisplay?(t.setPropertyVisibility("headerLayout",!0),t.setPropertyVisibility("account",!0),t.setPropertyVisibility("hashtag",!1),t.setPropertyVisibility("tweets",!1),t.setPropertyVisibility("limit",!0),t.setPropertyVisibility("tweetSettings",!0)):(t.setPropertyVisibility("headerLayout",!1),"hashtag"===t.widget.data.contentToDisplay&&(t.setPropertyVisibility("account",!1),t.setPropertyVisibility("hashtag",!0),t.setPropertyVisibility("tweets",!1),t.setPropertyVisibility("limit",!0),t.setPropertyVisibility("tweetSettings",!0)),"testimonials"===t.widget.data.contentToDisplay&&(t.setPropertyVisibility("account",!1),t.setPropertyVisibility("hashtag",!1),t.setPropertyVisibility("tweets",!0),t.setPropertyVisibility("limit",!1),t.setPropertyVisibility("tweetSettings",!1)))},e=function(t){t.widget.data.userId&&1!==t.widget.data.userId?(t.setPropertyVisibility("contentToDisplay",!0),t.setPropertyVisibility("account",!0),t.setPropertyVisibility("limit",!0),i(t)):(t.setPropertyVisibility("contentToDisplay",!1),t.setPropertyVisibility("account",!1),t.setPropertyVisibility("limit",!1))}}}]);