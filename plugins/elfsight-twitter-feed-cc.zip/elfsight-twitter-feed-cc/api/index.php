<?php

// Silence is golden ;)

?>